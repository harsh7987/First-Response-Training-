import SwiftUI

@main
struct FirstResponseTrainingApp: App {
    var body: some Scene {
        WindowGroup {
            WelcomeView()
        }
    }
}

