
import SwiftUI

struct Kudos: View {
    @State var wish = false
    @State var finishWish = false
    var body: some View {
        ZStack {
            ScrollView {
                VStack(spacing: 30){
                    Image("memoji")
                        .resizable()
                        .aspectRatio (contentMode: .fit)
                        .frame(height: getRect().width / 0.8)
                    
                    Text("You have done a great Job!")
                        .font(Font.system(size: 25,design:.default))
                        .lineSpacing (10.0)
                        .multilineTextAlignment (.center)
                    
                    Button (action: doAnimation, label: {
                        Text("Kudos")
                            .font(Font.system(size: 25,design:.default))
                            .padding (.vertical,12)
                            .padding (.horizontal,50)
                        
                        
                    })
                    .disabled(wish)
                }
                .onAppear {
                    doAnimation()
                }
            }
            EmitterView()
                .scaleEffect(wish ? 1 : 0, anchor: .top)
                .opacity(wish && !finishWish ? 1 : 0)
                .offset(y: wish ? 0 : getRect().height / 2)
                .ignoresSafeArea()
        }
    }
    
    func doAnimation() {
        withAnimation(.spring()) {
            wish = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            withAnimation(.easeInOut(duration: 1.5)){
                finishWish = true
            }
            //Reset
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                finishWish = false
                wish = false
            }
        }
    }
    
}

struct Kudos_Previews: PreviewProvider {
    static var previews: some View {
        Kudos()
    }
}

func getRect() -> CGRect{
    return UIScreen.main.bounds
}

struct EmitterView: UIViewRepresentable {
    
    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        view.backgroundColor = .clear
        
        let emitterLayer = CAEmitterLayer()
        emitterLayer.emitterShape = .line
        emitterLayer.emitterCells = createEmiterCells()
        
        //Size and position
        emitterLayer.emitterSize = CGSize(width: getRect().width, height: 1)
        emitterLayer.emitterPosition = CGPoint(x:getRect().width / 2, y: 0 )
        view.layer.addSublayer(emitterLayer)
        return view
    }
    
    func updateUIView(_ uiView: UIView, context: Context) {
    }
    
    func createEmiterCells() -> [CAEmitterCell] {
        
        var emitterCells: [CAEmitterCell] = []
        
        for index in 1...12 {
            let cell = CAEmitterCell()
            // Import White Particle Images...
            // Other wise color wont Work....
            cell.contents = UIImage(named: getImage(index: index))?.cgImage
            cell.color = getColor().cgColor
            // New Partcle Creation...
            cell.birthRate = 4.5
            // Particle Existence....
            cell.lifetime = 20
            // Velocity...
            cell.velocity = 120
            cell.scale = 0.2
            //cell.scaleRange = 0.1
            cell.emissionLongitude = .pi
            cell.emissionRange = 0.5
            cell.spin = 2
            cell.spinRange = 1
            
            emitterCells.append(cell)
        }
        
        return emitterCells
        
    }
    
    func getColor() -> UIColor {
        let colors: [UIColor] = [.systemPink, .systemYellow, .systemBlue, .systemPurple]
        return colors.randomElement()!
    }
    
    
    
    func getImage(index: Int) -> String {
        if (index < 4) {
            return "square"
        } else if index > 5 && index <= 8 {
            return "circle"
        } else {
            return "triangle"
        }
    }
    
}
