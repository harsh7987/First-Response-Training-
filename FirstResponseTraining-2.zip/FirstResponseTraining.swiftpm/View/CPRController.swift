import UIKit
import SceneKit
import ARKit


class CPRController: UIViewController, ARSCNViewDelegate, ARSessionDelegate {

    
    @IBOutlet var sceneView: ARSCNView!
    var patientNode: SCNNode?
    var cprPerformerNode: SCNNode?
    var planeNodes: [ARAnchor: SCNNode] = [:]

    var colorButtons: [UIButton] = []
    var textLabels: [UILabel] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
//        sceneView = ARSCNView(frame: .init(x: 0, y: 0, width: 400, height: 400))
//        view.addSubview(sceneView)
        sceneView.delegate = self
        sceneView.session.delegate = self
        sceneView.scene = SCNScene()

        
        addLighting()
        sceneView.showsStatistics = false
        setupPlaneDetection()
        
        let questionLabel = UILabel()
        questionLabel.translatesAutoresizingMaskIntoConstraints = false
        questionLabel.text = "This kid has burn wound so treat it"
        questionLabel.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        questionLabel.textColor = .white
        questionLabel.textAlignment = .center
        questionLabel.numberOfLines = 0
    questionLabel.layer.cornerRadius = 12
    questionLabel.layer.masksToBounds = true
    
    questionLabel.backgroundColor = UIColor.black.withAlphaComponent(0.5)
    view.addSubview(questionLabel)
        
        let instructionLabel = UILabel()
        instructionLabel.translatesAutoresizingMaskIntoConstraints = false
        instructionLabel.text = """
                    1. Move your device to detect a horizontal plane.
        
                    2. Tap on the grid to place the 3D model.
        
                    3. Tap your chosen option to save this kid.
        """
        instructionLabel.font = UIFont.systemFont(ofSize: 16)
        instructionLabel.textColor = .white
        instructionLabel.textAlignment = .left
        instructionLabel.numberOfLines = 0
    
    let instructionbgView: UIView = UIView()
    instructionbgView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
    instructionbgView.layer.cornerRadius = 12
    instructionbgView.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(instructionbgView)
    instructionbgView.addSubview(instructionLabel)
        
        NSLayoutConstraint.activate([
            questionLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            questionLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            questionLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            questionLabel.heightAnchor.constraint(equalToConstant: 24),

            
            instructionbgView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            instructionbgView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -2),
            instructionbgView.widthAnchor.constraint(equalToConstant: 220),
            instructionLabel.leadingAnchor.constraint(equalTo: instructionbgView.leadingAnchor, constant: 20),
            instructionLabel.trailingAnchor.constraint(equalTo: instructionbgView.trailingAnchor, constant: -20),

            instructionLabel.topAnchor.constraint(equalTo: instructionbgView.topAnchor, constant: 20),
            instructionLabel.bottomAnchor.constraint(equalTo: instructionbgView.bottomAnchor, constant: -20)
        ])

        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleScreenTap(_:)))
        sceneView.addGestureRecognizer(tapGesture)
        
        
    }

    func setupPlaneDetection() {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal]
        sceneView.session.run(configuration)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal]

        if #available(iOS 12.0, *) {
            configuration.environmentTexturing = .automatic
        }

        sceneView.session.run(configuration)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }

    // MARK: - Handle Screen Tap (Spawn CPR Receiver)
    @objc func handleScreenTap(_ gesture: UITapGestureRecognizer) {
        let touchLocation = gesture.location(in: sceneView)
        let hitResults = sceneView.hitTest(touchLocation, types: .existingPlaneUsingExtent)

        guard let hitResult = hitResults.first else { return }

        if patientNode == nil {
            patientNode = loadModel(named: "kidTakeCprFixed")
            patientNode?.position = SCNVector3(hitResult.worldTransform.columns.3.x,
                                               hitResult.worldTransform.columns.3.y,
                                               hitResult.worldTransform.columns.3.z)
            sceneView.scene.rootNode.addChildNode(patientNode!)

            showButtons()
        }
    }

    @objc func handleOptionSelection(_ sender: UIButton) {
        if sender.accessibilityIdentifier == "cpr" {
            startCPRAnimation()
        } else {
            let alert = UIAlertController(title: "Wrong Choice", message: "Please select the correct option!", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true, completion: nil)
        }
    }

    @objc func startCPRAnimation() {
        guard let patientNode = patientNode else { return }

        cprPerformerNode = loadModel(named: "kidGiveCprFixed")
        cprPerformerNode?.position = SCNVector3(patientNode.position.x - 0.1,
                                                patientNode.position.y - 0.001,
                                                patientNode.position.z - 0.1)
        cprPerformerNode?.eulerAngles.x = -0.1
        sceneView.scene.rootNode.addChildNode(cprPerformerNode!)

        if let animation = loadAnimation(named: "kidGiveCprFixed", animationIdentifier: "kidGiveCprFixed-1") {
            cprPerformerNode?.addAnimation(animation, forKey: "cpr")
        }
    }

    // MARK: - UI Setup
    func showButtons() {
        let buttonSize: CGFloat = 80
        let spacing: CGFloat = 40
        let labelHeight: CGFloat = 50
        
        let bgView = UIView()
        bgView.backgroundColor = .black.withAlphaComponent(0.5)
        bgView.translatesAutoresizingMaskIntoConstraints = false
        bgView.layer.cornerRadius = 24
        bgView.layer.masksToBounds = true
        view.addSubview(bgView)
        
        NSLayoutConstraint.activate([
            bgView.heightAnchor.constraint(equalToConstant: 180),
            bgView.widthAnchor.constraint(equalToConstant: 440),
            bgView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            bgView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -50)
        ])
        
        let items = [("cpr", "cpr", "CPR"), ("leg", "leg", "Leg"), ("orange-juice", "orange-juice", "Orange Juice")]
        let totalWidth = CGFloat(items.count) * buttonSize + CGFloat(items.count - 1) * spacing
        let startX = (view.frame.width - totalWidth) / 2

        for (index, item) in items.enumerated() {
            let button = UIButton(frame: CGRect(x: startX + CGFloat(index) * (buttonSize + spacing),
                                                y: view.frame.height - 200,
                                                width: buttonSize,
                                                height: buttonSize))
            
            if let image = UIImage(named: item.0) {
                button.setBackgroundImage(image, for: .normal)
                button.contentMode = .scaleAspectFit
            }

            button.layer.cornerRadius = buttonSize / 2
            button.layer.shadowColor = UIColor.black.cgColor
            button.layer.shadowOpacity = 0.3
            button.layer.shadowOffset = CGSize(width: 2, height: 2)
            button.layer.shadowRadius = 4
            button.accessibilityIdentifier = item.1
            button.addTarget(self, action: #selector(handleOptionSelection(_:)), for: .touchUpInside)
            view.addSubview(button)
            colorButtons.append(button)

            let label = UILabel(frame: CGRect(x: button.frame.midX - 45,
                                              y: button.frame.maxY + 5,
                                              width: 90,
                                              height: labelHeight))
            label.text = item.2
            label.textAlignment = .center
            label.font = UIFont.systemFont(ofSize: 16, weight: .bold)
            label.textColor = .white
            label.numberOfLines = 2
            label.lineBreakMode = .byWordWrapping
            view.addSubview(label)
            textLabels.append(label)
        }
    }

    func addLighting() {
        let lightNode = SCNNode()
        lightNode.light = SCNLight()
        lightNode.light?.type = .directional
        lightNode.position = SCNVector3(0, 2, 2)
        sceneView.scene.rootNode.addChildNode(lightNode)

        let ambientLight = SCNNode()
        ambientLight.light = SCNLight()
        ambientLight.light?.type = .ambient
        ambientLight.light?.intensity = 500
        sceneView.scene.rootNode.addChildNode(ambientLight)
    }

    func loadModel(named modelName: String) -> SCNNode {
        guard let scene = SCNScene(named: "art.scnassets/\(modelName).scn") ?? SCNScene(named: "\(modelName).scn") else {
            print("Error: Could not load model: \(modelName)")
            return SCNNode()
        }

        let node = SCNNode()
        for child in scene.rootNode.childNodes {
            node.addChildNode(child)
        }

        node.scale = SCNVector3(0.003, 0.003, 0.003)
        return node
    }

    func loadAnimation(named sceneName: String, animationIdentifier: String) -> CAAnimation? {
        guard let sceneURL = Bundle.main.url(forResource: "art.scnassets/\(sceneName)", withExtension: "scn") ?? Bundle.main.url(forResource: "\(sceneName)", withExtension: "scn"),
              let sceneSource = SCNSceneSource(url: sceneURL, options: nil),
              let animationObject = sceneSource.entryWithIdentifier(animationIdentifier, withClass: CAAnimation.self) else {
            print("Error: Could not load animation")
            return nil
        }

        animationObject.repeatCount = .greatestFiniteMagnitude
        animationObject.fadeInDuration = 1.0
        animationObject.fadeOutDuration = 0.5
        return animationObject
    }
}
