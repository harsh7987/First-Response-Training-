import SwiftUI

struct WelcomeView: View {

	var mattersPoints = ["• Emergencies happen anytime – Being prepared helps you stay calm and take the right steps.",
	"• Immediate action saves lives – Quick response can prevent serious harm.",
	"• Useful in daily life – From minor cuts to serious situations, knowing first aid is always helpful.",
	"• Confidence to help others – Whether it's a friend, family member, or stranger, you’ll know what to do.",
	"• Easy to learn, easy to apply – Simple training that can make a big difference."]
	@State var isShowNext = false
	var body: some View {
		NavigationStack {
			VStack {
				Text("Welcome to First Response Training")
					.font(.largeTitle)
					.fontWeight(.bold)
					.multilineTextAlignment(.center)
					.padding()
					.zIndex(1)
				
				ScrollView {
					VStack(alignment: .leading, spacing: 20) {
						Text("Learn Essential First Aid")
							.font(.title2)
							.fontWeight(.semibold)
							.padding(.top, 5)
						
						Text("This app helps you practice first response training using AR technology. It provides quick and easy guidance on how to handle situations like:")
							.font(.body)
							.foregroundColor(.gray)
						
						VStack(alignment: .leading, spacing: 8) {
							Text("• Blackouts – What to do if someone faints.")
							Text("• Cuts and wounds – How to stop bleeding and prevent infection.")
							Text("• CPR – Learn the right way to perform chest compressions.")
							Text("• Many more everyday first aid situations.")
						}
						.font(.body)
						.padding(.leading, 10)
						
						Text("Why It Matters")
							.font(.title2)
							.fontWeight(.semibold)
							.padding(.top, 10)
						
						VStack(alignment: .leading, spacing: 8) {
							ForEach(mattersPoints, id: \.self) { point in
								Text(point)
									.font(.body)
									.padding(.leading, 10)
							}
						}
						
					}
					.padding()
				}
				
				VStack {
					Button(action: {
						isShowNext.toggle()
					}) {
						Text("Let's Train")
							.font(.headline)
							.foregroundColor(.white)
							.padding()
							.frame(maxWidth: .infinity)
							.background(Color.blue)
							.cornerRadius(10)
					}
					.padding()
                    .background(Color(uiColor: .systemBackground))
				}
				.zIndex(1)

				.navigationDestination(isPresented: $isShowNext) {
                    DemoViewControllerRepresentable()
//                    CPRController()
				}
			}
		}
	}
}

struct WelcomeView_Previews: PreviewProvider {
	static var previews: some View {
		WelcomeView()
	}
}
