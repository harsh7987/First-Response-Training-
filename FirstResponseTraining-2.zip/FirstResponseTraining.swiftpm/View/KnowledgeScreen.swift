import SwiftUI

struct KnowledgeScreenView: View {
    var body: some View {
		KnowledgeScreen()
    }
}

#Preview {
	KnowledgeScreenView()
}

struct EmergencyCase: Identifiable {
	let id = UUID()
	let imageName: String
	let title: String
	let cause: String
	let symptoms: String
	let firstResponse: String
}

struct KnowledgeScreen: View {
	let cases: [EmergencyCase] = [
		EmergencyCase(imageName: "burn", title: "Burn", cause: "Exposure to heat, chemicals, or electricity can lead to burns, affecting skin layers.", symptoms: "Redness, pain, blistering, swelling, and possible tissue damage.", firstResponse: "Cool with running water, apply a clean bandage, and avoid popping blisters."),
		EmergencyCase(imageName: "chocking", title: "Choking", cause: "Food or foreign objects blocking the airway cause choking, preventing breathing.", symptoms: "Inability to speak, gasping, blue lips, and possible unconsciousness. ", firstResponse: "Perform Heimlich maneuver or back blows, and call emergency if needed."),
		EmergencyCase(imageName: "downning", title: "Drowning", cause: "Prolonged water immersion causes lack of oxygen, leading to unconsciousness.", symptoms: "Coughing, struggling to breathe, blue skin, or unresponsiveness.", firstResponse: "Pull person out, check breathing, start CPR if needed, call emergency."),
		EmergencyCase(imageName: "fire", title: "Fire Emergency", cause: "Exposure to fire, smoke inhalation, or burns from flames.", symptoms: "Coughing, breathing difficulty, burns, or carbon monoxide poisoning.", firstResponse: "Evacuate, stop-drop-roll if on fire, call emergency services."),
		EmergencyCase(imageName: "frature", title: "Fracture", cause: "A high-impact injury or fall can cause a broken bone.", symptoms: "Swelling, bruising, severe pain, or an unusual limb position.", firstResponse: "Immobilize the limb, apply ice, avoid movement, and seek medical help."),
		EmergencyCase(imageName: "headache", title: "Headache", cause: "Dehydration, stress, migraines, or eye strain can cause headaches.", symptoms: "Throbbing pain, sensitivity to light, nausea, or dizziness.", firstResponse: "Rest in a dark room, hydrate, and take pain relief medication if needed."),
		EmergencyCase(imageName: "stomachAche", title: "Stomach Ache", cause: "Indigestion, food poisoning, or infections lead to stomach pain.", symptoms: "Cramps, bloating, nausea, vomiting, or diarrhea.", firstResponse: "Rest, hydrate, eat light food, and use over-the-counter medicine if needed."),
		EmergencyCase(imageName: "chestpain", title: "Chest Pain", cause: "Heart issues, anxiety, acid reflux, or muscle strain can trigger chest pain.", symptoms: "Tightness, heaviness, shortness of breath, sweating, or dizziness.", firstResponse: "Call emergency services, keep patient calm, and loosen tight clothing."),
		EmergencyCase(imageName: "fever", title: "Fever", cause: "Infections, viruses, or inflammatory diseases can cause high body temperature.", symptoms: "Chills, sweating, fatigue, body aches, and shivering.", firstResponse: "Hydrate, rest, use fever-reducing medicine, and monitor temperature.")
	]

	@State private var showingAlert: Bool = false
	@State private var startQuiz: Bool = false
    
    var body: some View {
        VStack {
            Rectangle()
                .fill(Color(uiColor: .systemBackground))
                .frame(height: 20)
                .shadow(color: .black.opacity(0.1), radius: 6, x: 0, y: 10)
            ScrollView() {
                VStack(alignment: .leading) {
                    ForEach(cases,id: \.id) { emergencyCase in
                        HStack(alignment: .top, spacing: 10) {
                            Image(emergencyCase.imageName)
                                .resizable()
                                .frame(width: 160, height: 160)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                            
                            VStack(alignment: .leading, spacing: 5) {
                                Text(emergencyCase.title)
                                    .font(.headline)
                                
                                Text("Why it happens: \(emergencyCase.cause)")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                                
                                Text("How it feels: \(emergencyCase.symptoms)")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                                
                                Text("First Response: \(emergencyCase.firstResponse)")
                                    .font(.subheadline)
                                    .foregroundColor(.blue)
                            }
                            Spacer()
                        }
                        .frame(maxWidth: .infinity)
                        .padding(8)
                    }
                }
                .padding(.vertical, 48)
            }
            
            VStack {
                Button(action: {
                    showingAlert.toggle()
                }) {
                    Text("I am ready for Quiz")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                .padding()
            }
            .zIndex(1)
            
            .alert("Before You start!", isPresented: $showingAlert) {
                Button("Start Quize") {
                    startQuiz.toggle()
                }
                Button("Stay here", role: .cancel) {}
            } message: {
                Text(
                """
                Have you read all medical information?
                If not, go back and read all again.
                **Note:** To play this quiz, you need to know all the given medical knowledge. 
                """
                )
            }
            .navigationDestination(isPresented: $startQuiz) {
                QuizGameView()
            }
            
        }
        .clipped()
        .navigationBarBackButtonHidden()
        .navigationTitle("First Response Guide")
    }
}

struct KnowledgeScreen_Previews: PreviewProvider {
	static var previews: some View {
		KnowledgeScreen()
	}
}


