import UIKit
import SceneKit
import ARKit

class CutWoundController: UIViewController, ARSCNViewDelegate, ARSessionDelegate, UIGestureRecognizerDelegate {

    var sceneView: ARSCNView!
    
    var selectedItem: String = ""
    var colorButtons: [UIButton] = []
    var labelButtons: [UILabel] = []
    var modelPlaced = false
    var planeNodes: [ARAnchor: SCNNode] = [:]
    var isAntisepticApplied = false
    
    var textLabels: [UILabel] = []
    
    var modelNode: SCNNode?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        sceneView = ARSCNView(frame: view.frame)
        view.addSubview(sceneView)
        sceneView.delegate = self
        sceneView.session.delegate = self
        sceneView.scene = SCNScene()
        
        addLighting()
        setupPlaneDetection()
        setupColorButtons(stage: 1)
        
        let questionLabel = UILabel()
        questionLabel.translatesAutoresizingMaskIntoConstraints = false
        questionLabel.text = "This kid has a cut wound. Please treat it."
        questionLabel.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        questionLabel.textColor = .white
        questionLabel.textAlignment = .center
        questionLabel.numberOfLines = 0
        questionLabel.layer.cornerRadius = 12
        questionLabel.layer.masksToBounds = true

        questionLabel.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        view.addSubview(questionLabel)
        
        let instructionLabel = UILabel()
        instructionLabel.translatesAutoresizingMaskIntoConstraints = false
        instructionLabel.text = """
        1. Move your device to detect a horizontal plane.
        
        2. Tap on the grid to place the 3D model.
        
        3. Slightly hold and drag your chosen option and drop it onto the wound.
        
        4. Pinch to scale or rotate the model as needed.
        """
        instructionLabel.font = UIFont.systemFont(ofSize: 20)
        instructionLabel.textColor = .white
        instructionLabel.numberOfLines = 0
        instructionLabel.textAlignment = .left
       
        
        let instructionbgView: UIView = UIView()
        instructionbgView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        instructionbgView.layer.cornerRadius = 12
        instructionbgView.translatesAutoresizingMaskIntoConstraints = false


        view.addSubview(instructionbgView)
        instructionbgView.addSubview(instructionLabel)

        
        instructionLabel.textAlignment = .center
        
        NSLayoutConstraint.activate([
            questionLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            questionLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            questionLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            questionLabel.heightAnchor.constraint(equalToConstant: 24),

            
            instructionbgView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            instructionbgView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -2),
            instructionbgView.widthAnchor.constraint(equalToConstant: 220),
            instructionLabel.leadingAnchor.constraint(equalTo: instructionbgView.leadingAnchor, constant: 20),
            instructionLabel.trailingAnchor.constraint(equalTo: instructionbgView.trailingAnchor, constant: -20),

            instructionLabel.topAnchor.constraint(equalTo: instructionbgView.topAnchor, constant: 20),
            instructionLabel.bottomAnchor.constraint(equalTo: instructionbgView.bottomAnchor, constant: -20)
            
        ])
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        sceneView.addGestureRecognizer(tapGesture)
        
        let pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(handlePinch(_:)))
        sceneView.addGestureRecognizer(pinchGesture)
        
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(handleRotation(_:)))
        sceneView.addGestureRecognizer(panGesture)
    }

    
    @objc func handlePinch(_ gesture: UIPinchGestureRecognizer) {
        guard let node = modelNode else { return }
        
        if gesture.state == .changed {
            let scaleFactor = Float(gesture.scale)
            let currentScale = node.scale
            node.scale = SCNVector3(currentScale.x * scaleFactor,
                                    currentScale.y * scaleFactor,
                                    currentScale.z * scaleFactor)
            
            gesture.scale = 1.0
        }
    }
    
    @objc func handleRotation(_ gesture: UIPanGestureRecognizer) {
        
        guard let node = modelNode else { return }
          
          let translation = gesture.translation(in: sceneView)
          
          
          let rotationDelta = Float(translation.x) * 0.005
          
          node.eulerAngles.y += rotationDelta
          
          gesture.setTranslation(.zero, in: sceneView)
    }

    func setupPlaneDetection() {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal]
        sceneView.session.run(configuration)
    }

    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        guard let planeAnchor = anchor as? ARPlaneAnchor else { return }
        
        let plane = SCNPlane(width: CGFloat(planeAnchor.extent.x), height: CGFloat(planeAnchor.extent.z))
        plane.firstMaterial?.diffuse.contents = UIColor.gray.withAlphaComponent(0.6)
        plane.firstMaterial?.isDoubleSided = true
        
        let planeNode = SCNNode(geometry: plane)
        planeNode.eulerAngles.x = -.pi / 2
        node.addChildNode(planeNode)
        
        planeNodes[planeAnchor] = planeNode
    }

    @objc func handleTap(_ gesture: UITapGestureRecognizer) {
        if modelPlaced { return }

        let tapLocation = gesture.location(in: sceneView)
        let hitTestResults = sceneView.hitTest(tapLocation, types: .existingPlaneUsingExtent)

        if let hitResult = hitTestResults.first {
            let position = SCNVector3(hitResult.worldTransform.columns.3.x,
                                      hitResult.worldTransform.columns.3.y,
                                      hitResult.worldTransform.columns.3.z)
            
            loadModel(at: position)
            modelPlaced = true
        }
    }

    func loadModel(at position: SCNVector3) {
        guard let injuredScene = SCNScene(named: "art.scnassets/injuredKid3Fixed.scn") else {
            print("⚠️ Model file not found!")
            return
        }

        let modelNode = SCNNode()
        for child in injuredScene.rootNode.childNodes {
            modelNode.addChildNode(child)
        }

        modelNode.position = position
        modelNode.scale = SCNVector3(0.003, 0.003, 0.003)

        sceneView.scene.rootNode.addChildNode(modelNode)
        
        self.modelNode = modelNode
        print("✅ Model placed at \(position) with wound texture!")
    }
    
    func addLighting() {
        let lightNode = SCNNode()
        lightNode.light = SCNLight()
        lightNode.light?.type = .directional
        lightNode.position = SCNVector3(0, 2, 2)
        sceneView.scene.rootNode.addChildNode(lightNode)

        let ambientLight = SCNNode()
        ambientLight.light = SCNLight()
        ambientLight.light?.type = .ambient
        ambientLight.light?.intensity = 500
        sceneView.scene.rootNode.addChildNode(ambientLight)
    }

    func setupColorButtons(stage: Int) {
        colorButtons.forEach { $0.removeFromSuperview() }
        textLabels.forEach { $0.removeFromSuperview() }
        colorButtons.removeAll()
        textLabels.removeAll()
        
        let bgView = UIView()
        bgView.backgroundColor = .black.withAlphaComponent(0.5)
        bgView.translatesAutoresizingMaskIntoConstraints = false
        bgView.layer.cornerRadius = 24
        bgView.layer.masksToBounds = true
        view.addSubview(bgView)
        
        NSLayoutConstraint.activate([
            bgView.heightAnchor.constraint(equalToConstant: 180),
            bgView.widthAnchor.constraint(equalToConstant: 440),
            bgView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            bgView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -50)
        ])
    
        let items: [(String, String, String)] = stage == 1
            ? [("soap_water", "soap_water", "Soap Water"),
               ("antiseptic", "antiseptic", "Antiseptic Liquid"),
               ("alcohol", "alcohol", "Alcohol")]
            : [("resized_image", "bandage", "Bandage"),
               ("ice_cube", "ice", "Ice Cube"),
               ("water_bottle", "water", "Water")]


        let buttonSize: CGFloat = 80
        let spacing: CGFloat = 40
        let labelHeight: CGFloat = 50
        let totalWidth = CGFloat(items.count) * buttonSize + CGFloat(items.count - 1) * spacing
        let startX = (view.frame.width - totalWidth) / 2


        for (index, item) in items.enumerated() {
            let button = UIButton(frame: CGRect(x: startX + CGFloat(index) * (buttonSize + spacing),
                                                y: view.frame.height - 200,
                                                width: buttonSize,
                                                height: buttonSize))

            if let image = UIImage(named: item.0) {
                button.setBackgroundImage(image, for: .normal)
                button.contentMode = .scaleAspectFit
            }

            button.layer.cornerRadius = buttonSize / 2
            button.layer.shadowColor = UIColor.black.cgColor
            button.layer.shadowOpacity = 0.3
            button.layer.shadowOffset = CGSize(width: 2, height: 2)
            button.layer.shadowRadius = 4
            button.tag = index
            button.accessibilityIdentifier = item.1
            button.addTarget(self, action: #selector(startDrag(_:)), for: .touchDown)
            button.addTarget(self, action: #selector(animateButtonPress(_:)), for: .touchDown)
            button.addTarget(self, action: #selector(animateButtonRelease(_:)), for: [.touchUpInside, .touchDragExit])

            view.addSubview(button)
            colorButtons.append(button)

            let label = UILabel(frame: CGRect(x: button.frame.midX - 45,
                                              y: button.frame.maxY + 5,
                                              width: 90,
                                              height: labelHeight))
            label.text = item.2
            label.textAlignment = .center
            label.font = UIFont.systemFont(ofSize: 16, weight: .bold)
            label.textColor = .white
            label.numberOfLines = 2
            label.lineBreakMode = .byWordWrapping
            label.adjustsFontSizeToFitWidth = false
            view.addSubview(label)
            textLabels.append(label)
        }
    }
    
    @objc func animateButtonPress(_ sender: UIButton) {
        UIView.animate(withDuration: 0.1, animations: {
            sender.transform = CGAffineTransform(scaleX: 0.9, y: 0.9)
        })
    }

    @objc func animateButtonRelease(_ sender: UIButton) {
        UIView.animate(withDuration: 0.1, animations: {
            sender.transform = .identity
        })
    }

    @objc func startDrag(_ sender: UIButton) {
        selectedItem = sender.accessibilityIdentifier ?? ""
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(handlePan(_:)))
        sender.addGestureRecognizer(panGesture)
        print("🎨 Dragging started with: \(selectedItem)")
    }

    @objc func handlePan(_ gesture: UIPanGestureRecognizer) {
        let location = gesture.location(in: view)
        gesture.view?.center = CGPoint(x: location.x, y: location.y)

        if gesture.state == .ended, modelPlaced {
            let convertedLocation = sceneView.convert(location, to: sceneView)
            let hitTestResults = sceneView.hitTest(convertedLocation, options: [SCNHitTestOption.boundingBoxOnly: true])

            if let hitNode = hitTestResults.first?.node {
                applyColorToWound(hitNode)
            }
        }
    }
    
   
    func applyColorToWound(_ node: SCNNode) {
        print("🎯 Hit Detected on Node: \(node.name ?? "Unknown")")

      
        if node.name == "wound-001" {
            applyEffectToNode(node)
            return
        } else {
            print("❌ ERROR: Wound `wound-001` not found in hierarchy!")
        }

       
        if let woundNode = sceneView.scene.rootNode.childNode(withName: "wound-001", recursively: true) {
            print("✅ Found wound node inside model: \(woundNode.name ?? "Unknown")")
            applyEffectToNode(woundNode)
        } else {
            print("❌ ERROR: Wound `wound-001` not found in hierarchy!")
        }
    }

    func applyEffectToNode(_ node: SCNNode) {
        if let material = node.geometry?.firstMaterial {
            if selectedItem == "antiseptic" && !isAntisepticApplied {
                material.diffuse.contents = UIImage(named: "drops.png")
                isAntisepticApplied = true
                setupColorButtons(stage: 2)
                
              
                let glowColor = UIColor.yellow
                material.emission.contents = glowColor
                material.emission.intensity = 1.0

                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    material.emission.intensity = 0.0
                    print("✨ Golden glow effect removed")
                }

               
                let feedbackGenerator = UINotificationFeedbackGenerator()
                feedbackGenerator.notificationOccurred(.success)
                print("🔊 Haptic Feedback Triggered")
                
               
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.resetColorButtons()
                }
                showAlert(title: "👍 Good!", message: "Wound is clean now!")

            } else if selectedItem == "bandage" && isAntisepticApplied {
                material.diffuse.contents = UIImage(named: "resized_image.png")
                
              
                let glowColor = UIColor.yellow
                material.emission.contents = glowColor
                material.emission.intensity = 1.0

                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    material.emission.intensity = 0.0
                    print("✨ Golden glow effect removed")
                }

                
                let feedbackGenerator = UINotificationFeedbackGenerator()
                feedbackGenerator.notificationOccurred(.success)
                print("🔊 Haptic Feedback Triggered")
                
               
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.resetColorButtons()
                }
                showAlert(title: "🎉 Success!", message: "Wound covered with a bandage!")

            } else {
               
                let feedbackGenerator = UINotificationFeedbackGenerator()
                feedbackGenerator.notificationOccurred(.success)
                print("🔊 Haptic Feedback Triggered")
                
                showAlert(title: "❌ Wrong!", message: "Try Again!")
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.resetColorButtons()
                }
            }
        }
    }

    func resetColorButtons() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            UIView.animate(withDuration: 0.5, animations: {
                for (index, button) in self.colorButtons.enumerated() {
                    let buttonSize: CGFloat = 80  // ✅ Ensure consistent size
                    let spacing: CGFloat = 40
                    let totalWidth = CGFloat(self.colorButtons.count) * buttonSize + CGFloat(self.colorButtons.count - 1) * spacing
                    let startX = (self.view.frame.width - totalWidth) / 2
                    let newX = startX + CGFloat(index) * (buttonSize + spacing)

                    button.frame.origin = CGPoint(x: newX, y: self.view.frame.height - 200)  // ✅ Fixed Position
                }
            })
            print("🎨 Color buttons reset to original positions correctly")
        }
    }


    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

