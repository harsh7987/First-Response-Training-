import SwiftUI

struct QuizQuestion {
	let question: String
	let options: [String]
	let correctAnswer: Int
	let image: String
}

struct QuizGameView: View {

	let quizQuestions: [QuizQuestion] = [
        QuizQuestion(question: "How should you treat a sprained ankle?",
                     options: ["Apply heat", "Walk it off", "Use the R.I.C.E method", "Massage the area"],
                     correctAnswer: 2,
                     image: "strain"),
		QuizQuestion(question: "What should you do first for a burn?",
					 options: ["Apply Oil", "Pop the blister", "Wrap in cloth", "Cool with water"],
					 correctAnswer: 3,
					 image: "burn"),
		QuizQuestion(question: "What is the best first response for choking?",
					 options: ["Give water", "Perform Heimlich maneuver", "Call doctor", "Pat back lightly"],
					 correctAnswer: 1,
					 image: "chocking"),
		QuizQuestion(question: "What should you do if someone is rescued from drowning and is unconscious?",
					 options: ["Give food", "Wait for help", "Perform CPR", "Slap back"],
					 correctAnswer: 2,
					 image: "downning"),
		QuizQuestion(question: "What is the first step for a fracture?",
					 options: ["Immobilize it", "Move the limb", "Massage the area", "Apply heat"],
					 correctAnswer: 0,
					 image: "frature"),
		QuizQuestion(question: "How do you handle chest pain?",
					 options: ["Wait for it to pass", "Give aspirin & call emergency",
							   "Make the person run", "Ignore it"],
					 correctAnswer: 1,
					 image: "chestpain"),
        QuizQuestion(question: "What is the first step when treating a cut?",
                     options: ["Apply pressure to stop bleeding", "Wash with soap immediately", "Cover with cloth", "Ignore small cuts"],
                     correctAnswer: 0,
                     image: "cut"),

       
	]

	@Environment(\.presentationMode) var presentation
	@State private var currentQuestionIndex = 0
	@State private var timeRemaining = 30
	@State private var selectedAnswerIndex: Int? = nil
	@State private var showAlert = false
	@State private var alertMessage = ""
	@State private var showFinalScreen = false
	@State private var timerColor: Color = .green
	@State private var score = 0
	@State private var isQuit = false
	@State private var moveToNext = false
    @State private var timer: Timer?
    let totalTime = 30


    var body: some View {
        ScrollView {
            VStack {
                if !showFinalScreen {
                    ZStack {
                        Image(quizQuestions[currentQuestionIndex].image)
                            .resizable()
                            .frame(width: 200, height: 200)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                            .offset(x: -100)
                        
                        HStack {
                            Spacer()
                            Circle()
                                .fill(timerColor)
                                .frame(width: 80, height: 80)
                                .overlay(
                                    Text("\(timeRemaining)")
                                        .font(.largeTitle)
                                        .bold()
                                        .foregroundColor(.white)
                                )
                                .padding()
                        }
                        .padding()
                    }
                }
                
                if showFinalScreen {
                    VStack {
                        Text("🎉 You did a very good job! 🎉")
                            .font(.title)
                            .bold()
                            .padding()
                        
                        Button("Move Next") {
                            moveToNext.toggle()
                        }
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                    }
                } else {
                    VStack(spacing: 24) {
                        
                        Text(quizQuestions[currentQuestionIndex].question)
                            .font(.largeTitle)
                            .bold()
                            .padding()
                        
                        ForEach(0..<4) { index in
                            Button(action: {
                                handleAnswerSelection(index)
                            }) {
                                ZStack {
                                    ZStack {
                                        Rectangle()
                                            .foregroundColor(Color.white.opacity(0.2))
                                            .cornerRadius(38)
                                            .padding(.bottom, 12)
                                            .padding(.leading, 12)
                                    }
                                    .frame(height: 80)
                                    
                                    Text(quizQuestions[currentQuestionIndex].options[index])
                                        .font(.title)
                                        .bold()
                                        .foregroundColor(.white)
                                        .offset(y: -6)
                                    HStack {
                                        Spacer()
                                        if let selected = selectedAnswerIndex {
                                            if selected == index {
                                                Image(systemName: selected == quizQuestions[currentQuestionIndex].correctAnswer ?  "checkmark.circle.fill" : "xmark.circle.fill")
                                                    .resizable()
                                                    .frame(width: 40, height: 40)
                                                    .foregroundColor(Color.black.opacity(0.4))
                                            }
                                        }
                                    }
                                    .padding()
                                    .offset(y: -6)
                                }
                                .frame(height: 80)
                                .background(selectedAnswerIndex == index ?
                                            (index == quizQuestions[currentQuestionIndex].correctAnswer ? Color.green : Color.red) :
                                                Color.blue)
                                
                                .cornerRadius(40)
                            }
                            .disabled(selectedAnswerIndex != nil) // Disable after selection
                        }
                    }
                    .padding()
                }
            }
        }
        .onAppear {
            startTimer()
        }
        .alert(isPresented: $showAlert) {
            if selectedAnswerIndex == quizQuestions[currentQuestionIndex].correctAnswer {
                return Alert(title: Text("✅ Correct!"), message: Text("Great job!"), dismissButton: .default(Text("Next"), action: moveToNextQuestion))
            } else if isQuit {
                return Alert(title: Text("Quit"), message: Text("Do you want to quit the quiz?"), primaryButton: .default(Text("Yes"), action: goToKnowledgeScreen), secondaryButton: .default(Text("No"), action: quitQuiz))
            } else {
                return Alert(title: Text("❌ Try Again"), message: Text("Would you like to retry or review?"), primaryButton: .default(Text("Try Again"), action: resetQuestion), secondaryButton: .default(Text("Go Back"), action: goToKnowledgeScreen))
            }
        }
        .navigationTitle("First Aid Quiz")
        .navigationBarBackButtonHidden()
        .navigationDestination(isPresented: $moveToNext) {
            ARTrainingIntroView()
        }
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Quit") {
                    showAlert.toggle()
                    isQuit.toggle()
                }
            }
        }
    }

    private func startTimer() {
        timeRemaining = totalTime
        timerColor = .green
        
        // Invalidate existing timer before starting a new one
        timer?.invalidate()
        
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
            if timeRemaining > 0 {
                timeRemaining -= 1
                if timeRemaining <= 10 {
                    timerColor = .red
                }
            } else {
                timer.invalidate()
                showAlert = true
                alertMessage = "Time's up! Try again?"
            }
        }
    }

	private func handleAnswerSelection(_ index: Int) {
		selectedAnswerIndex = index
		if index == quizQuestions[currentQuestionIndex].correctAnswer {
			showAlert = true
			score += 1
		} else {
			showAlert = true
		}
	}

	private func moveToNextQuestion() {
		if currentQuestionIndex < quizQuestions.count - 1 {
			currentQuestionIndex += 1
			resetQuestion()
		} else {
			showFinalScreen = true
		}
	}

	private func quitQuiz() {
		isQuit.toggle()
	}

	private func resetQuestion() {
		selectedAnswerIndex = nil
		timeRemaining = 30
		timerColor = .green
		startTimer()
	}

	private func resetQuiz() {
		currentQuestionIndex = 0
		showFinalScreen = false
		resetQuestion()
	}

	private func goToKnowledgeScreen() {
		self.presentation.wrappedValue.dismiss()
	}

	
}

struct QuizGameView_Previews: PreviewProvider {
	static var previews: some View {
		QuizGameView()
	}
}



struct CircularTimerView: View {
	@Binding var timeRemaining: Int
	@State private var progress: CGFloat = 1.0 // Full progress
	@State private var timerColor: Color = .green

	let totalTime: Int

	var body: some View {
		ZStack {

			Circle()
				.trim(from: 0, to: progress)
				.stroke(timerColor, style: StrokeStyle(lineWidth: 20, lineCap: .round))
				.rotationEffect(.degrees(-90)) // Starts from top

			Circle()
				.fill(Color.black)
				.stroke(Color.gray.opacity(0.3), lineWidth: 2)

			Text("\(timeRemaining)")
				.font(.largeTitle)
				.bold()
				.foregroundColor(.white)
		}
		.frame(width: 150, height: 150)
		.background(Circle().fill(timerColor)) // Filled background
		.onChange(of: timeRemaining) { newValue in
			progress = CGFloat(newValue) / CGFloat(totalTime) // Update progress
			updateColor()
		}
	}

	private func updateColor() {
		if timeRemaining > totalTime / 2 {
			timerColor = .green
		} else if timeRemaining > totalTime / 4 {
			timerColor = .orange
		} else {
			timerColor = .red
		}
	}
}



struct ARTrainingIntroView: View {
	@State private var showARView = false

	var body: some View {
		NavigationStack {
			VStack(spacing: 20) {
				Spacer()

				// AR Icon
				Image(systemName: "arkit")
					.resizable()
					.scaledToFit()
					.frame(width: 100, height: 100)
					.foregroundColor(.blue)

				// Title
				Text("AR First Response Training")
					.font(.title)
					.bold()
					.multilineTextAlignment(.center)

				// Step-by-Step Instructions
				VStack(alignment: .leading, spacing: 10) {
					Text("📍 **Step 1:** Move to an open space.")
					Text("🔍 **Step 2:** Point your device at a flat surface and tap to place the virtual child in AR.")
					Text("🆘 **Step 3:** Read the issue the child is facing (e.g., burn, choking, fracture).")
					Text("🎯 **Step 4:** Drag and drop the correct first-aid response item to help the child.")
					Text("🏆 **Goal:** Apply the correct treatment to complete the training successfully.")
				}
				.padding()
				.background(Color(UIColor.secondarySystemBackground))
				.cornerRadius(10)

				// Start Button
				Button(action: {
					showARView = true
				}) {
					Text("Start Training")
						.font(.headline)
						.frame(maxWidth: .infinity)
						.padding()
						.background(Color.blue)
						.foregroundColor(.white)
						.cornerRadius(10)
				}
				.padding(.horizontal)

				Spacer()
			}
			.padding()
			.fullScreenCover(isPresented: $showARView) {
//				DemoViewControllerRepresentable()
				Kudos()
			}
		}
	}
}

struct DemoView: View {
	@State var showARView: Bool = false
	var body: some View {
		Text("")
			.fullScreenCover(isPresented: $showARView) {
				// DemoViewController
			}

	}
}

struct DemoViewControllerRepresentable: UIViewControllerRepresentable {
	func makeUIViewController(context: Context) -> CPRController {
        let vc = UIStoryboard(name: "Main", bundle: nil)
            .instantiateViewController(identifier: "CPRController") as! CPRController
		return vc
	}

	func updateUIViewController(_ uiViewController: CPRController, context: Context) {}
}

class DemoViewController: UIViewController {
	override func viewDidLoad() {
		super.viewDidLoad()
		view.backgroundColor = .blue

		let closeButton = UIButton(type: .system)
		closeButton.setTitle("Close", for: .normal)
		closeButton.addTarget(self, action: #selector(dismissView), for: .touchUpInside)
		closeButton.frame = CGRect(x: 20, y: 50, width: 100, height: 50)
		view.addSubview(closeButton)
	}

	@objc func dismissView() {
		dismiss(animated: true, completion: nil)
	}
}
